// Copyright (c) 2023-present The Bitcoin Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or https://www.opensource.org/licenses/mit-license.php.

#include <bench/bench.h>
#include <random.h>
#include <test/util/setup_common.h>
#include <uint256.h>
#include <util/check.h>
#include <util/fs.h>
#include <util/translation.h>
#include <wallet/context.h>
#include <wallet/db.h>
#include <wallet/wallet.h>
#include <wallet/walletutil.h>

#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace wallet {
static void WalletCreate(benchmark::Bench& bench, bool encrypted)
{
    auto test_setup = MakeNoLogFileContext<TestingSetup>();
    FastRandomContext random;

    WalletContext context;
    context.args = &test_setup->m_args;
    context.chain = test_setup->m_node.chain.get();

    DatabaseOptions options;
    options.require_format = DatabaseFormat::SQLITE;
    options.require_create = true;
    options.create_flags = WALLET_FLAG_DESCRIPTORS;

    if (encrypted) {
        options.create_passphrase = random.rand256().ToString();
    }

    DatabaseStatus status;
    bilingual_str error_string;
    std::vector<bilingual_str> warnings;

    const auto wallet_path = test_setup->m_path_root / "test_wallet";
    const auto wallet_name = fs::PathToString(wallet_path);

    std::shared_ptr<CWallet> wallet;
    auto cleanup{[&] {
        if (!wallet) return;
        // Release wallet
        RemoveWallet(context, wallet, /*load_on_start=*/std::nullopt);
        WaitForDeleteWallet(std::move(wallet));
        fs::remove(wallet_path / "wallet.dat");
        fs::remove(wallet_path);
    }};
    bench.setup(cleanup).run([&] {
        wallet = CreateWallet(context, wallet_name, /*load_on_start=*/std::nullopt, options, status, error_string, warnings);
        assert(status == DatabaseStatus::SUCCESS);
        assert(wallet != nullptr);
    });
    cleanup();
}

static void WalletCreatePlain(benchmark::Bench& bench) { WalletCreate(bench, /*encrypted=*/false); }
static void WalletCreateEncrypted(benchmark::Bench& bench) { WalletCreate(bench, /*encrypted=*/true); }

BENCHMARK(WalletCreatePlain);
BENCHMARK(WalletCreateEncrypted);

} // namespace wallet
